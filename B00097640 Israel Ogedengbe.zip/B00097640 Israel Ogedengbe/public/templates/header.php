<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title><?php echo $title = "Header"; ?></title>

        <title>Registration System</title>

    <link rel="stylesheet" href="css/style.css">
</head>

<body>
<h1>Registration System</h1>