CREATE DATABASE visitors;

use visitors;

CREATE TABLE products (
  id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  description VARCHAR(30) NOT NULL,
  price VARCHAR(30) NOT NULL);

