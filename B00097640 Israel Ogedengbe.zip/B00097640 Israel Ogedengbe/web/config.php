<?php


$host       = "127.0.0.1";
$username   = "root";
$password   = "pass";
$dbname     = "visitors"; // will use later
$dsn        = "mysql:127.0.0.1=$host;dbname=$dbname"; // will use later
$options    = array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);

