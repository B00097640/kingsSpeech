<?php
require_once __DIR__ . '/../vendor/autoload.php';

use Itb\WebApplication;

$app = new WebApplication();
$app->run();

